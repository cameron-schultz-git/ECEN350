---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Output**
If applicable, add the output from ChampSim to help explain your problem.

**Desktop (please complete the following information):**
 - OS: [e.g. iOS]
 - Compiler [e.g. GCC, LLVM]
 - Version [e.g. 22]

**Additional context**
Add any other context about the problem here.
